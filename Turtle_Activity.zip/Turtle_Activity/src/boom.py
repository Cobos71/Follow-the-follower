#!/usr/bin/env python

# Equipo
# A01706219 - Rodrigo Marquina Magaña
# A0127596  - Raúl Sebastían Uribe Sosa
# A01274631 - José Pablo Cobos Austria 


import rospy
import time
import os
import re
from std_msgs.msg import String
from rosgraph_msgs.msg import Log

def setup():
    global classturtoise
    classturtoise = open('class_init.txt', 'w')

setup()

#Se crea una clase coalisiones con sus funciones y variables correspondientes 
class Crash:
    
    #Función que activa suscripción
    def __init__(messenger):
        messenger.sub = rospy.Subscriber("/rosout_agg", Log, messenger.callback)
        messenger.prev_x = 0
        messenger.prev_y = 0
        messenger.count  = 0

    #Función para mandar el envio de mensajes y manejo de datos
    def callback(messenger, info):
        info_msg = info.msg
        if re.match(r'Oh no! I hit the wall!', info_msg):
            match = re.search(r'x=(.*), y=(.*)]', info_msg)
            x = float(match.group(1)); y = float(match.group(2))
            same_spot = (int(x) == messenger.prev_x)and(int(y) == messenger.prev_y)
            if not same_spot:
                info_msg = 'Boom, you have crash against a wall in x = {0} and y = {1}'.format(x, y)
                classturtoise.write(info_msg+os.linesep)
                print(info_msg)
                messenger.count += 1
            messenger.prev_x = int(x); messenger.prev_y = int(y)

if __name__ == '__main__':
    col = Crash()
    try:
        #Se van contando las coalisiones que ocurren y se se van acumulando 
        rospy.init_node('crashes')
        rospy.spin()
        final_msg = "\n Final acount of the coalitions that ocurred : {0}".format(col.count)
        classturtoise.write(final_msg)
        print(final_msg)
        time.sleep(5)
        classturtoise.close()
    except rospy.ROSInterruptException:
        classturtoise.close()